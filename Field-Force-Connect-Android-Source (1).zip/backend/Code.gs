/**
 * Field Force Connect - Google Apps Script Backend (Code.gs)
 * Spreadsheet ID: 1HJXVPi8bs1pbaibq5_AdP04mbwngTouv
 *
 * IMPORTANT FOR GOOGLE DRIVE PHOTO LINKS:
 * After pasting this code in Extensions > Apps Script:
 * 1. Select "authorizeGoogleDrive" in the top function dropdown and click "Run" once
 *    to approve Google Drive permissions (Review Permissions -> Allow).
 * 2. Click Deploy > Manage deployments > Edit (pencil icon) > Version: New version > Deploy.
 */

const SPREADSHEET_ID = '1HJXVPi8bs1pbaibq5_AdP04mbwngTouv';
const PHOTO_ROOT_FOLDER_NAME = 'Field Force Connect - Activity Photos';

/**
 * Run this function ONCE from the Apps Script editor toolbar ("Run" button)
 * to trigger Google's permission prompt for Google Drive & Google Sheets.
 */
function authorizeGoogleDrive() {
  const folder = getOrCreateFolder_(PHOTO_ROOT_FOLDER_NAME, null);
  const book = SpreadsheetApp.openById(SPREADSHEET_ID);
  Logger.log('SUCCESS! Connected to Sheet: ' + book.getName());
  Logger.log('SUCCESS! Connected to Drive Folder: ' + folder.getName() + ' -> ' + folder.getUrl());
}

function doGet(e) {
  try {
    const params = (e && e.parameter) || {};
    const action = params.action;

    if (action === 'login') return json(login(params.email));
    if (action === 'get_entities') return json(getEntities(params.entityType, params.userId));
    if (action === 'get_product_demos') return json(getProductDemonstrations(params.userId));
    if (action === 'get_products') return json(getProducts());
    if (action === 'get_orders') return json(getOrders(params.userId));
    if (action === 'get_sheet_names') return json(getSheetNames());
    if (action === 'get_activities') return json(getActivities(params.activityType, params.userId));
    if (action === 'test_drive') return json(testDriveStatus());

    return json({ ok: false, error: 'Unknown action: ' + action });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    const action = body.action;

    if (action === 'login') return json(login(body.email));
    if (action === 'get_entities') return json(getEntities(body.entityType, body.userId));
    if (action === 'create_entity') return json(createEntity(body.entityType, body.userId, body.fields || {}));
    if (action === 'create_activity') return json(createActivity(body.activity || {}));
    if (action === 'save_day_entry') return json(saveDayEntry(body.entry || {}));
    if (action === 'submit_order') return json(submitOrder(body.order || {}));
    if (action === 'get_orders') return json(getOrders(body.userId));
    if (action === 'get_sheet_names') return json(getSheetNames());
    if (action === 'test_drive') return json(testDriveStatus());

    return json({ ok: false, error: 'Unknown action: ' + action });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function ss() {
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

function getSheetNames() {
  const allSheets = ss().getSheets().map(s => s.getName());
  let driveOk = false;
  let driveFolderUrl = '';
  try {
    const folder = getOrCreateFolder_(PHOTO_ROOT_FOLDER_NAME, null);
    driveOk = true;
    driveFolderUrl = folder.getUrl();
  } catch (e) {
    driveOk = false;
  }
  return { ok: true, sheets: allSheets, driveOk: driveOk, driveFolderUrl: driveFolderUrl };
}

function testDriveStatus() {
  try {
    const folder = getOrCreateFolder_(PHOTO_ROOT_FOLDER_NAME, null);
    return {
      ok: true,
      folderName: folder.getName(),
      folderUrl: folder.getUrl()
    };
  } catch (err) {
    return {
      ok: false,
      error: 'Google Drive permission not authorized yet: ' + String(err)
    };
  }
}

/**
 * Finds or creates a Google Drive folder by name.
 */
function getOrCreateFolder_(folderName, parentFolder) {
  const cleanName = String(folderName || PHOTO_ROOT_FOLDER_NAME).trim();
  const folderIterator = parentFolder
    ? parentFolder.getFoldersByName(cleanName)
    : DriveApp.getFoldersByName(cleanName);

  if (folderIterator.hasNext()) {
    return folderIterator.next();
  }
  return parentFolder
    ? parentFolder.createFolder(cleanName)
    : DriveApp.createFolder(cleanName);
}

/**
 * Decodes base64 photos, saves them to Google Drive under
 * "Field Force Connect - Activity Photos/<subfolderName>",
 * and returns { urls: string[], error?: string }.
 */
function uploadPhotosToDrive_(photoList, recordId, subfolderName) {
  if (!photoList || !Array.isArray(photoList) || photoList.length === 0) {
    return { urls: [] };
  }

  const urls = [];
  try {
    const rootFolder = getOrCreateFolder_(PHOTO_ROOT_FOLDER_NAME, null);
    const targetFolder = subfolderName
      ? getOrCreateFolder_(subfolderName, rootFolder)
      : rootFolder;

    for (let i = 0; i < photoList.length; i++) {
      const item = photoList[i];
      if (!item) continue;

      let rawBase64 = '';
      let mimeType = 'image/jpeg';
      let fileName = (recordId || 'PHOTO-' + new Date().getTime()) + '_' + (i + 1) + '.jpg';

      if (typeof item === 'string') {
        rawBase64 = item;
      } else if (typeof item === 'object') {
        rawBase64 = item.data || item.base64 || item.Photo_Data_Base64 || '';
        if (item.mimeType) mimeType = String(item.mimeType);
        if (item.fileName) fileName = String(item.fileName);
      }

      if (!rawBase64) continue;

      // Strip data URI prefix if present (e.g. "data:image/jpeg;base64,...")
      if (rawBase64.indexOf('base64,') !== -1) {
        const parts = rawBase64.split('base64,');
        const header = parts[0];
        rawBase64 = parts[1];
        const mimeMatch = header.match(/data:([^;]+);/);
        if (mimeMatch && mimeMatch[1]) {
          mimeType = mimeMatch[1];
        }
      }

      // Clean any whitespace/newlines in base64 payload
      rawBase64 = rawBase64.replace(/\s/g, '');
      const decodedBytes = Utilities.base64Decode(rawBase64);
      const blob = Utilities.newBlob(decodedBytes, mimeType, fileName);
      const file = targetFolder.createFile(blob);

      // Make link viewable so clicking from Google Sheets opens directly
      try {
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      } catch (shareErr) {
        // Ignore if domain policy restricts ANYONE_WITH_LINK; file.getUrl() still works for organization users
      }

      urls.push(file.getUrl());
    }

    return { urls: urls };
  } catch (err) {
    Logger.log('Drive upload error: ' + err);
    return { urls: urls, error: String(err) };
  }
}

function rows(sheetName) {
  const sh = ss().getSheetByName(sheetName);
  if (!sh) throw new Error('Missing sheet: ' + sheetName);
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(String);
  return values.slice(1).filter(r => r.some(v => v !== '')).map(r => {
    const o = {};
    headers.forEach((h, i) => o[h] = r[i] ?? '');
    return o;
  });
}

function getUser(userId) {
  const allUsers = rows('Users');
  const user = allUsers.find(u => String(u.User_ID) === String(userId));
  if (user) return user;
  return null;
}

function login(email) {
  const normalized = String(email || '').trim().toLowerCase();
  const allUsers = rows('Users');
  const user = allUsers.find(u =>
    String(u.Email || '').trim().toLowerCase() === normalized &&
    String(u.Status || '').toLowerCase() === 'active'
  );
  if (user) return { ok: true, user: user };

  return {
    ok: false,
    error: 'Email "' + email + '" not found in Users sheet with Status = Active. Please add this row to the Users tab.'
  };
}

function inGeo(row, user) {
  if (!user || (!user.Territory && !user.Region && !user.District && !user.State)) return true;
  if (user.Territory && row.Territory) return String(row.Territory).toLowerCase() === String(user.Territory).toLowerCase();
  if (user.Region && row.Region) return String(row.Region).toLowerCase() === String(user.Region).toLowerCase();
  if (user.District && row.District) return String(row.District).toLowerCase() === String(user.District).toLowerCase();
  if (user.State && row.State) return String(row.State).toLowerCase() === String(user.State).toLowerCase();
  return true;
}

function getEntities(type, userId) {
  const user = getUser(userId);
  const sheet = type === 'Distributor' ? 'Distributor_Master'
    : type === 'Retailer' ? 'Retailer_Master'
    : 'Farmer_Master';
  const allRows = rows(sheet);
  const items = allRows.filter(r =>
    String(r.Status || 'Active').toLowerCase() === 'active' && inGeo(r, user)
  );
  return { ok: true, items: items.length > 0 ? items : allRows };
}

function createEntity(entityType, userId, fields) {
  const user = userId ? getUser(userId) : null;
  const sheetName = entityType === 'Distributor' ? 'Distributor_Master'
    : entityType === 'Retailer' ? 'Retailer_Master'
    : 'Farmer_Master';
  const prefix = entityType === 'Distributor' ? 'DIST-'
    : entityType === 'Retailer' ? 'RET-'
    : 'FRM-';
  const idField = entityType === 'Distributor' ? 'Distributor_ID'
    : entityType === 'Retailer' ? 'Retailer_ID'
    : 'Farmer_ID';
  const nameField = entityType === 'Distributor' ? 'Distributor_Name'
    : entityType === 'Retailer' ? 'Retailer_Name'
    : 'Farmer_Name';

  const newId = fields[idField] || (prefix + new Date().getTime());
  const record = {
    ...fields,
    [idField]: newId,
    [nameField]: fields[nameField] || fields.Name || '',
    Territory: fields.Territory || (user ? user.Territory : ''),
    District: fields.District || (user ? user.District : ''),
    Region: fields.Region || (user ? user.Region : ''),
    State: fields.State || (user ? user.State : ''),
    Status: 'Active',
    Created_By: userId || '',
    Created_Date: new Date()
  };

  appendRowToSheet_(sheetName, record);
  return { ok: true, item: record };
}

function getProducts() {
  const prods = rows('product_master').filter(p =>
    p.Product_Code && String(p.Status || 'Active').toLowerCase() !== 'inactive'
  );
  return { ok: true, items: prods };
}

function getOrders(userId) {
  const allOrders = rows('Orders');
  const userOrders = (userId && allOrders.some(o => String(o.Created_By_User_ID) === String(userId)))
    ? allOrders.filter(o => String(o.Created_By_User_ID) === String(userId))
    : allOrders;

  let allItems = [];
  try {
    allItems = rows('Order_Items');
  } catch (e) {
    allItems = [];
  }

  const itemsByOrder = {};
  allItems.forEach(item => {
    const oid = String(item.Order_ID);
    if (!itemsByOrder[oid]) itemsByOrder[oid] = [];
    itemsByOrder[oid].push({
      productCode: item.Product_ID || item.Product_Code,
      productName: item.Product_Name,
      quantity: Number(item.Quantity || 0),
      packSize: item.Unit || 'Units',
      subtotal: 0
    });
  });

  const enriched = userOrders.map(o => ({
    ...o,
    items: itemsByOrder[String(o.Order_ID)] || []
  }));

  return { ok: true, items: enriched };
}

function getProductDemonstrations(userId) {
  const book = ss();
  const allSheets = book.getSheets().map(s => s.getName());
  const demoSheet = allSheets.find(s => s.toLowerCase().includes('demo')) || 'Product_Demonstrations';
  try {
    const items = rows(demoSheet).filter(a =>
      (!userId || String(a.User_ID) === String(userId))
    );
    return { ok: true, items: items };
  } catch (e) {
    return { ok: true, items: [] };
  }
}

function getActivities(activityType, userId) {
  const book = ss();
  const allSheets = book.getSheets().map(s => s.getName());
  let targetSheet = 'Field_Activities';
  if (activityType) {
    const l = activityType.toLowerCase();
    targetSheet = allSheets.find(s => s.toLowerCase().includes(l)) || targetSheet;
  }
  try {
    const items = rows(targetSheet).filter(a =>
      (!userId || String(a.User_ID) === String(userId))
    );
    return { ok: true, sheet: targetSheet, items };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

function appendRowToSheet_(sheetName, record) {
  const book = ss();
  const sh = book.getSheetByName(sheetName);
  if (!sh) throw new Error('Missing sheet: ' + sheetName);
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  const rowValues = headers.map(h => record[h] !== undefined ? record[h] : '');
  sh.appendRow(rowValues);
}

function submitOrder(order) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const userId = order.Created_By_User_ID || 'USR-PILOT';
    const existingUser = getUser(userId);
    const userName = order.Created_By_Name || (existingUser ? existingUser.Name : 'Field Officer');
    const userEmail = order.Created_By_Email || (existingUser ? existingUser.Email : '');

    const distributorId = String(order.Customer_ID || '');
    if (!distributorId) throw new Error('Customer_ID (Distributor) is required');

    const allDistributors = rows('Distributor_Master');
    const distributor = allDistributors.find(d => String(d.Distributor_ID) === distributorId);
    const distributorName = distributor ? (distributor.Distributor_Name || distributor.Name) : (order.Customer_Name || distributorId);

    const items = Array.isArray(order.items) ? order.items : [];
    if (items.length === 0) throw new Error('At least one product item is required');

    const products = rows('product_master');
    const orderId = 'ORD-' + new Date().getTime();
    const now = new Date();

    // 1. Write Header to Orders sheet
    const orderRecord = {
      Order_ID: orderId,
      Created_By_User_ID: userId,
      Created_By_Name: userName,
      Created_By_Email: userEmail,
      Customer_Type: 'Distributor',
      Customer_ID: distributorId,
      Customer_Name: distributorName,
      Order_DateTime: now,
      Status: 'Waiting for Accounts Verification',
      Submitted_At: now,
      Accounts_Reviewed_By: '',
      Accounts_Reviewed_At: '',
      Accounts_Decision: '',
      Rejection_Reason: '',
      Dispatch_By: '',
      Dispatch_At: '',
      Dispatch_Reference: '',
      Delivery_Status: 'Pending',
      Delivery_Confirmed_At: '',
      Delivery_Remarks: order.remarks || '',
      Last_Updated_At: now
    };
    appendRowToSheet_('Orders', orderRecord);

    // 2. Write Line items to Order_Items sheet
    items.forEach((item, index) => {
      const code = String(item.productCode || item.Product_Code || item.Product_ID || '').trim();
      const matchedProd = products.find(p => String(p.Product_Code).trim() === code) || {};
      const itemRecord = {
        Order_Item_ID: orderId + '-' + (index + 1),
        Order_ID: orderId,
        Product_ID: code,
        Product_Name: matchedProd.Product_Name || item.productName || code,
        Quantity: Number(item.quantity || 1),
        Unit: matchedProd.Pack_Size || 'Units',
        Created_At: now
      };
      appendRowToSheet_('Order_Items', itemRecord);
    });

    // 3. Write Initial Audit to Order_Status_History sheet
    const historyRecord = {
      History_ID: 'HIST-' + new Date().getTime() + '-1',
      Order_ID: orderId,
      Previous_Status: '',
      New_Status: 'Waiting for Accounts Verification',
      Action_By_User_ID: userId,
      Action_By_Name: userName,
      Action_By_Role: 'Field Officer',
      Action_DateTime: now,
      Remarks: 'Order submitted from mobile application'
    };
    appendRowToSheet_('Order_Status_History', historyRecord);

    return {
      ok: true,
      orderId: orderId,
      status: 'Waiting for Accounts Verification'
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * Trigger: Runs when Accounts modifies Accounts_Decision in the Orders sheet.
 */
function onEdit(e) {
  if (!e || !e.range) return;

  const sheet = e.range.getSheet();
  if (sheet.getName() !== 'Orders') return;

  const row = e.range.getRow();
  if (row <= 1) return; // Header row

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const colIndex = e.range.getColumn();
  const editedHeader = headers[colIndex - 1];

  if (editedHeader !== 'Accounts_Decision') return;

  const decision = String(e.value || '').trim();
  if (decision !== 'Approved' && decision !== 'Rejected') return;

  const rowValues = sheet.getRange(row, 1, 1, headers.length).getValues()[0];
  const orderData = {};
  headers.forEach((h, i) => orderData[h] = rowValues[i]);

  const orderId = String(orderData.Order_ID || '');
  if (!orderId) return;

  const previousStatus = String(orderData.Status || 'Waiting for Accounts Verification');
  const reviewer = String(orderData.Accounts_Reviewed_By || '').trim() || 'Accounts';
  const rejectionReason = String(orderData.Rejection_Reason || '').trim();
  const now = new Date();

  const newStatus = decision === 'Approved' ? 'Waiting for Dispatch' : 'Rejected';

  const statusCol = headers.indexOf('Status') + 1;
  const reviewedAtCol = headers.indexOf('Accounts_Reviewed_At') + 1;
  const lastUpdatedCol = headers.indexOf('Last_Updated_At') + 1;

  if (statusCol > 0) sheet.getRange(row, statusCol).setValue(newStatus);
  if (reviewedAtCol > 0) sheet.getRange(row, reviewedAtCol).setValue(now);
  if (lastUpdatedCol > 0) sheet.getRange(row, lastUpdatedCol).setValue(now);

  const historyRecord = {
    History_ID: 'HIST-' + new Date().getTime(),
    Order_ID: orderId,
    Previous_Status: previousStatus,
    New_Status: newStatus,
    Action_By_User_ID: '',
    Action_By_Name: reviewer,
    Action_By_Role: 'Accounts',
    Action_DateTime: now,
    Remarks: decision === 'Approved' ? 'Approved by Accounts' : (rejectionReason || 'Rejected by Accounts')
  };

  appendRowToSheet_('Order_Status_History', historyRecord);
}

function saveDayEntry(entry) {
  const now = new Date();
  const recordId = 'DAY-' + now.getTime();
  const user = entry.User_ID ? getUser(entry.User_ID) : null;

  // Upload odometer photo to Google Drive if base64 data was provided
  let photoUrl = entry.Photo_URL || '';
  if (!photoUrl && entry.Photo_Data_Base64) {
    const uploadRes = uploadPhotosToDrive_(
      [{ data: entry.Photo_Data_Base64, mimeType: 'image/jpeg', fileName: recordId + '_odometer.jpg' }],
      recordId,
      'Start_End_Day'
    );
    if (uploadRes.urls && uploadRes.urls.length > 0) {
      photoUrl = uploadRes.urls.join(', ');
    }
  }

  const record = {
    Record_ID: recordId,
    User_ID: entry.User_ID || (user ? user.User_ID : ''),
    User_Email: entry.User_Email || (user ? user.Email : ''),
    User_Name: entry.User_Name || (user ? user.Name : ''),
    Entry_Type: entry.Entry_Type || 'Start Day',
    Entry_Date: Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd'),
    Entry_Time: Utilities.formatDate(now, Session.getScriptTimeZone(), 'HH:mm:ss'),
    Odometer_KM: entry.Odometer_KM || 0,
    Latitude: entry.Latitude || '',
    Longitude: entry.Longitude || '',
    Photo_URL: photoUrl,
    Photo_URLs: photoUrl,
    Sync_Status: 'Synced',
    Created_At: now
  };
  appendRowToSheet_('Start_End_Day', record);
  return { ok: true, recordId: record.Record_ID, photoUrl: photoUrl };
}

/**
 * Intelligent Activity Routing, Google Drive Photo Upload & Auto-Creation:
 * 1. Uploads attached photos (Photo_Data_Base64_List) to Google Drive folder
 *    "Field Force Connect - Activity Photos/<TargetSheet>" and writes the shareable
 *    Google Drive links to the Photo_URLs column.
 * 2. Routes each activity to its dedicated Google Sheet tab:
 *    - Distributor Visits -> 'Distributor_Visits'
 *    - Retailer Visits -> 'Retailer_Visits'
 *    - Farmer Visits -> 'Farmer_Visits'
 *    - Product Demonstration -> 'Product_Demonstrations'
 *    - Farmer Meeting -> 'Farmer_Meetings'
 *    - Field Day -> 'Field_Days'
 */
function createActivity(activity) {
  if (!activity) throw new Error('Activity data missing');
  const userId = activity.User_ID || '';
  const user = userId ? getUser(userId) : null;
  const userName = activity.User_Name || (user ? user.Name : 'Field Officer');

  const book = ss();
  const existingSheets = book.getSheets().map(s => s.getName());

  const actType = String(activity.Activity_Type || activity.Activity_Category || '').toLowerCase();
  const entityType = String(activity.Entity_Type || '').toLowerCase();

  let targetSheetName = '';

  if (actType.includes('distributor') || entityType === 'distributor') {
    targetSheetName = existingSheets.find(s => {
      const l = s.toLowerCase();
      return l.includes('distributor') && (l.includes('visit') || l.includes('activity') || l.includes('act'));
    }) || existingSheets.find(s => s.toLowerCase() === 'distributor_visits' || s.toLowerCase() === 'distributor visits' || s.toLowerCase() === 'distributor visit') || 'Distributor_Visits';
  } else if (actType.includes('retailer') || entityType === 'retailer') {
    targetSheetName = existingSheets.find(s => {
      const l = s.toLowerCase();
      return l.includes('retailer') && (l.includes('visit') || l.includes('activity') || l.includes('act'));
    }) || existingSheets.find(s => s.toLowerCase() === 'retailer_visits' || s.toLowerCase() === 'retailer visits' || s.toLowerCase() === 'retailer visit') || 'Retailer_Visits';
  } else if (actType.includes('demonstration') || actType.includes('demo')) {
    targetSheetName = existingSheets.find(s => {
      const l = s.toLowerCase();
      return l.includes('demo');
    }) || 'Product_Demonstrations';
  } else if (actType.includes('meeting') || actType.includes('farmer meeting')) {
    targetSheetName = existingSheets.find(s => {
      const l = s.toLowerCase();
      return l.includes('meet');
    }) || 'Farmer_Meetings';
  } else if (actType.includes('field day') || actType.includes('field_day')) {
    targetSheetName = existingSheets.find(s => {
      const l = s.toLowerCase();
      return l.includes('field') && l.includes('day');
    }) || 'Field_Days';
  } else if (actType.includes('farmer') || entityType === 'farmer') {
    targetSheetName = existingSheets.find(s => {
      const l = s.toLowerCase();
      return l.includes('farmer') && (l.includes('visit') || l.includes('activity'));
    }) || 'Farmer_Visits';
  } else {
    targetSheetName = existingSheets.find(s => s.toLowerCase().includes('field_activities') || s.toLowerCase().includes('activities')) || 'Field_Activities';
  }

  // Upload any attached photos to Google Drive and generate shareable links
  const rawPhotoList = Array.isArray(activity.Photo_Data_Base64_List)
    ? activity.Photo_Data_Base64_List
    : (activity.Photo_Data_Base64 ? [{ data: activity.Photo_Data_Base64, mimeType: 'image/jpeg' }] : []);

  const uploadResult = uploadPhotosToDrive_(
    rawPhotoList,
    activity.Activity_ID || ('ACT-' + new Date().getTime()),
    targetSheetName
  );
  const uploadedUrls = uploadResult.urls || [];
  const photoUrlsString = uploadedUrls.length > 0
    ? uploadedUrls.join(', ')
    : (activity.Photo_URLs && String(activity.Photo_URLs).startsWith('http') ? String(activity.Photo_URLs) : '');

  // Get or auto-create sheet tab
  let sh = book.getSheetByName(targetSheetName);
  const now = new Date();

  const standardHeaders = [
    'Activity_ID', 'User_ID', 'User_Name', 'Activity_Type', 'Activity_Category',
    'Entity_Type', 'Entity_ID', 'Entity_Name', 'Activity_Date',
    'Start_Time', 'End_Time', 'Duration_Min',
    'Start_Latitude', 'Start_Longitude', 'End_Latitude', 'End_Longitude',
    'Purpose', 'Outcome', 'Remarks', 'Photo_Count', 'Photo_URLs',
    'Farmer_Name', 'Farmer_Phone', 'Crop', 'Variety', 'Village',
    'Demo_Qty_KG', 'Demo_Acreage', 'Farmers_Attended',
    'Created_DateTime'
  ];

  if (!sh) {
    sh = book.insertSheet(targetSheetName);
    sh.appendRow(standardHeaders);
  }

  const lastCol = sh.getLastColumn();
  let headers = [];
  if (lastCol > 0) {
    headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  } else {
    headers = standardHeaders;
    sh.appendRow(headers);
  }

  // Ensure existing sheet tab has a Photo_URLs (or Photo_URL) column header so Drive links are never lost
  const hasPhotoUrlColumn = headers.some(h => {
    const clean = h.trim().toLowerCase();
    return clean === 'photo_urls' || clean === 'photo_url' || clean === 'photo urls' || clean === 'photo url' || clean === 'photo_links' || clean === 'drive_link';
  });

  if (!hasPhotoUrlColumn) {
    const newColIndex = headers.length + 1;
    sh.getRange(1, newColIndex).setValue('Photo_URLs');
    headers.push('Photo_URLs');
  }

  const activityData = {
    ...activity,
    User_Name: userName || activity.User_Name || '',
    Photo_Count: uploadedUrls.length > 0 ? uploadedUrls.length : (activity.Photo_Count || 0),
    Photo_URLs: photoUrlsString,
    Photo_URL: photoUrlsString,
    Photo_Links: photoUrlsString,
    Drive_Link: photoUrlsString,
    Created_DateTime: activity.Created_DateTime || now.toISOString(),
  };

  // Remove raw base64 payloads so they are never written directly into spreadsheet cells
  delete activityData.Photo_Data_Base64_List;
  delete activityData.Photo_Data_Base64;

  const rowValues = headers.map(header => {
    const cleanH = header.trim();
    if (activityData[cleanH] !== undefined && activityData[cleanH] !== null) return activityData[cleanH];
    const foundKey = Object.keys(activityData).find(k => k.toLowerCase() === cleanH.toLowerCase());
    if (foundKey && activityData[foundKey] !== undefined && activityData[foundKey] !== null) return activityData[foundKey];
    return '';
  });

  sh.appendRow(rowValues);

  return {
    ok: true,
    activityId: activity.Activity_ID,
    sheet: targetSheetName,
    photoUrls: photoUrlsString,
    photoCount: uploadedUrls.length,
    photoError: uploadResult.error || null
  };
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

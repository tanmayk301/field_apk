import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FieldForceConnectApp());
}

const String kDefaultWebAppUrl =
    'https://script.google.com/macros/s/AKfycby6cWKwVXVOdTZd9Nr561X7_nF9NXEr3vVi3bn3KVn5dfPw6lslfZdcT_xH8TjuWgrB/exec';
const String kSpreadsheetId = '1HJXVPi8bs1pbaibq5_AdP04mbwngTouv';

/// Maps each activity type to its dedicated Google Sheet tab
String resolveSheetNameForActivity(String activityType) {
  final normalized = activityType.trim().toLowerCase();
  if (normalized.contains('distributor')) return 'Distributor_Visits';
  if (normalized.contains('retailer')) return 'Retailer_Visits';
  if (normalized.contains('farmer visit')) return 'Farmer_Visits';
  if (normalized.contains('demo')) return 'Product_Demonstrations';
  if (normalized.contains('meeting')) return 'Farmer_Meetings';
  if (normalized.contains('field day')) return 'Field_Days';
  return 'Visits';
}

class FieldForceConnectApp extends StatelessWidget {
  const FieldForceConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Field Force Connect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF059669),
          primary: const Color(0xFF059669),
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
      ),
      home: const RootBootstrapScreen(),
    );
  }
}

class RootBootstrapScreen extends StatefulWidget {
  const RootBootstrapScreen({super.key});

  @override
  State<RootBootstrapScreen> createState() => _RootBootstrapScreenState();
}

class _RootBootstrapScreenState extends State<RootBootstrapScreen> {
  bool _loading = true;
  String? _userEmail;
  String? _userName;
  String? _userRole;
  String _webAppUrl = kDefaultWebAppUrl;

  @override
  void initState() {
    super.initState();
    _loadSession();
  }

  Future<void> _loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _userEmail = prefs.getString('ff_user_email');
      _userName = prefs.getString('ff_user_name');
      _userRole = prefs.getString('ff_user_role') ?? 'Field Officer';
      _webAppUrl = prefs.getString('ff_webapp_url') ?? kDefaultWebAppUrl;
      _loading = false;
    });
  }

  Future<void> _saveLogin(String name, String email, String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ff_user_name', name);
    await prefs.setString('ff_user_email', email);
    await prefs.setString('ff_user_role', role);
    setState(() {
      _userName = name;
      _userEmail = email;
      _userRole = role;
    });
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('ff_user_name');
    await prefs.remove('ff_user_email');
    setState(() {
      _userName = null;
      _userEmail = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_userEmail == null || _userEmail!.isEmpty) {
      return LoginScreen(onLogin: _saveLogin);
    }
    return MainShellScreen(
      userName: _userName ?? 'Field Officer',
      userEmail: _userEmail!,
      userRole: _userRole ?? 'Field Officer',
      webAppUrl: _webAppUrl,
      onLogout: _logout,
    );
  }
}

class LoginScreen extends StatefulWidget {
  final Future<void> Function(String name, String email, String role) onLogin;
  const LoginScreen({super.key, required this.onLogin});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  String _role = 'Field Sales Officer';

  void _submit() {
    final name = _nameCtrl.text.trim();
    final email = _emailCtrl.text.trim();
    if (name.isEmpty || email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your name and email ID')),
      );
      return;
    }
    widget.onLogin(name, email, _role);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: const Color(0xFF059669),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Icon(Icons.location_on,
                        color: Colors.white, size: 34),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Field Force Connect',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Native Android Field Activity, Visit & Order App',
                    style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                  ),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _nameCtrl,
                    decoration: InputDecoration(
                      labelText: 'Officer Full Name',
                      prefixIcon: const Icon(Icons.person_outline),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      labelText: 'Official Email ID',
                      prefixIcon: const Icon(Icons.email_outlined),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _role,
                    items: const [
                      DropdownMenuItem(
                        value: 'Field Sales Officer',
                        child: Text('Field Sales Officer'),
                      ),
                      DropdownMenuItem(
                        value: 'Territory Manager',
                        child: Text('Territory Manager'),
                      ),
                      DropdownMenuItem(
                        value: 'Regional Manager',
                        child: Text('Regional Manager'),
                      ),
                    ],
                    onChanged: (v) => setState(() => _role = v ?? _role),
                    decoration: InputDecoration(
                      labelText: 'Designation / Role',
                      prefixIcon: const Icon(Icons.badge_outlined),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: _submit,
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF059669),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    icon: const Icon(Icons.login),
                    label: const Text(
                      'Sign In to Field Force',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShellScreen extends StatefulWidget {
  final String userName;
  final String userEmail;
  final String userRole;
  final String webAppUrl;
  final VoidCallback onLogout;

  const MainShellScreen({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.userRole,
    required this.webAppUrl,
    required this.onLogout,
  });

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _tabIndex = 0;
  List<Map<String, dynamic>> _visits = [];
  List<Map<String, dynamic>> _orders = [];
  List<Map<String, dynamic>> _pendingQueue = [];
  bool _dayStarted = false;
  String? _dayStartTime;
  String? _startOdometer;
  bool _syncing = false;

  @override
  void initState() {
    super.initState();
    _loadLocalRecords();
  }

  Future<void> _loadLocalRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final visitsJson = prefs.getString('ff_visits_v2');
    final ordersJson = prefs.getString('ff_orders_v2');
    final queueJson = prefs.getString('ff_pending_queue_v2');
    setState(() {
      if (visitsJson != null) {
        _visits = List<Map<String, dynamic>>.from(jsonDecode(visitsJson));
      }
      if (ordersJson != null) {
        _orders = List<Map<String, dynamic>>.from(jsonDecode(ordersJson));
      }
      if (queueJson != null) {
        _pendingQueue = List<Map<String, dynamic>>.from(jsonDecode(queueJson));
      }
      _dayStarted = prefs.getBool('ff_day_started') ?? false;
      _dayStartTime = prefs.getString('ff_day_start_time');
      _startOdometer = prefs.getString('ff_start_odo');
    });
  }

  Future<void> _persistRecords() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ff_visits_v2', jsonEncode(_visits));
    await prefs.setString('ff_orders_v2', jsonEncode(_orders));
    await prefs.setString('ff_pending_queue_v2', jsonEncode(_pendingQueue));
  }

  Future<Position?> _captureGps() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return null;
      }
      if (permission == LocationPermission.deniedForever) return null;
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
    } catch (_) {
      return null;
    }
  }

  Future<String?> _uploadPhotoToDrive(File imageFile, String visitId) async {
    try {
      final bytes = await imageFile.readAsBytes();
      final b64 = base64Encode(bytes);
      final fileName =
          'Visit_${visitId}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final payload = {
        'action': 'uploadPhoto',
        'fileName': fileName,
        'mimeType': 'image/jpeg',
        'base64Data': b64,
        'data': {
          'fileName': fileName,
          'mimeType': 'image/jpeg',
          'base64Data': b64,
          'image': 'data:image/jpeg;base64,$b64',
        }
      };

      final response = await http
          .post(
            Uri.parse(widget.webAppUrl),
            headers: {'Content-Type': 'text/plain;charset=utf-8'},
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 25));

      if (response.statusCode == 200 || response.statusCode == 302) {
        final decoded = jsonDecode(response.body);
        final url = decoded['fileUrl'] ??
            decoded['url'] ??
            decoded['photoUrl'] ??
            decoded['driveUrl'];
        if (url != null && url.toString().startsWith('http')) {
          return url.toString();
        }
      }
    } catch (_) {}
    return null;
  }

  Future<bool> _postToGoogleSheet(Map<String, dynamic> body) async {
    try {
      final response = await http
          .post(
            Uri.parse(widget.webAppUrl),
            headers: {'Content-Type': 'text/plain;charset=utf-8'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 25));
      return response.statusCode >= 200 && response.statusCode < 400;
    } catch (_) {
      return false;
    }
  }

  Future<void> _syncPendingQueue() async {
    if (_syncing || _pendingQueue.isEmpty) return;
    setState(() => _syncing = true);
    final remaining = <Map<String, dynamic>>[];
    for (final item in _pendingQueue) {
      final ok = await _postToGoogleSheet(item);
      if (!ok) {
        remaining.add(item);
      }
    }
    setState(() {
      _pendingQueue = remaining;
      _syncing = false;
    });
    await _persistRecords();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(remaining.isEmpty
              ? 'All records synced to Google Sheets!'
              : '${remaining.length} item(s) still pending offline sync.'),
        ),
      );
    }
  }

  Future<void> _recordVisit(Map<String, dynamic> visitData) async {
    final sheetName =
        resolveSheetNameForActivity(visitData['activityType'] ?? 'Visit');
    visitData['sheetName'] = sheetName;
    visitData['targetSheet'] = sheetName;

    final payload = {
      'action': 'addVisit',
      'sheetName': sheetName,
      'targetSheet': sheetName,
      'spreadsheetId': kSpreadsheetId,
      'data': {
        'Visit_ID': visitData['id'],
        'Date': visitData['date'],
        'User_Email': widget.userEmail,
        'Officer_Name': widget.userName,
        'Activity_Type': visitData['activityType'],
        'Sheet_Name': sheetName,
        'Customer_Name': visitData['customerName'],
        'Contact_Person': visitData['contactPerson'],
        'Mobile': visitData['mobile'],
        'Village_City': visitData['locationName'],
        'Crop_Focus': visitData['cropFocus'],
        'Products_Discussed': visitData['productsDiscussed'],
        'Notes': visitData['notes'],
        'Start_Time': visitData['startTime'],
        'End_Time': visitData['endTime'],
        'Duration_Minutes': visitData['durationMinutes'],
        'GPS_Latitude': visitData['latitude'],
        'GPS_Longitude': visitData['longitude'],
        'Photo_URLs': visitData['photoUrls'] ?? '',
        'Status': 'Completed',
      }
    };

    final synced = await _postToGoogleSheet(payload);
    visitData['synced'] = synced;
    setState(() {
      _visits.insert(0, visitData);
      if (!synced) {
        _pendingQueue.add(payload);
      }
    });
    await _persistRecords();
  }

  Future<void> _recordOrder(Map<String, dynamic> orderData) async {
    final payload = {
      'action': 'addOrder',
      'sheetName': 'Orders',
      'targetSheet': 'Orders',
      'spreadsheetId': kSpreadsheetId,
      'data': {
        'Order_ID': orderData['id'],
        'Date': orderData['date'],
        'User_Email': widget.userEmail,
        'Officer_Name': widget.userName,
        'Customer_Name': orderData['customerName'],
        'Customer_Type': orderData['customerType'],
        'Product_Name': orderData['productName'],
        'Quantity': orderData['quantity'],
        'Unit_Price': orderData['unitPrice'],
        'Order_Value': orderData['orderValue'],
        'Payment_Terms': orderData['paymentTerms'],
        'Transporter_Name': orderData['transporterName'] ?? '',
        'Tracking_Number': orderData['trackingNumber'] ?? '',
        'Dispatch_Date': orderData['dispatchDate'] ?? '',
        'Dispatch_Remarks': orderData['dispatchRemarks'] ?? '',
        'Status': orderData['status'] ?? 'Booked',
      }
    };

    final synced = await _postToGoogleSheet(payload);
    orderData['synced'] = synced;
    setState(() {
      _orders.insert(0, orderData);
      if (!synced) {
        _pendingQueue.add(payload);
      }
    });
    await _persistRecords();
  }

  Future<void> _toggleAttendance() async {
    final prefs = await SharedPreferences.getInstance();
    final pos = await _captureGps();
    final nowStr = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());

    if (!_dayStarted) {
      setState(() {
        _dayStarted = true;
        _dayStartTime = nowStr;
      });
      await prefs.setBool('ff_day_started', true);
      await prefs.setString('ff_day_start_time', nowStr);
      await _postToGoogleSheet({
        'action': 'addAttendance',
        'sheetName': 'Attendance',
        'data': {
          'Date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
          'User_Email': widget.userEmail,
          'Officer_Name': widget.userName,
          'Event': 'START_DAY',
          'Timestamp': nowStr,
          'Latitude': pos?.latitude ?? '',
          'Longitude': pos?.longitude ?? '',
        }
      });
    } else {
      setState(() {
        _dayStarted = false;
      });
      await prefs.setBool('ff_day_started', false);
      await _postToGoogleSheet({
        'action': 'addAttendance',
        'sheetName': 'Attendance',
        'data': {
          'Date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
          'User_Email': widget.userEmail,
          'Officer_Name': widget.userName,
          'Event': 'END_DAY',
          'Timestamp': nowStr,
          'Latitude': pos?.latitude ?? '',
          'Longitude': pos?.longitude ?? '',
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardTab(
        userName: widget.userName,
        userRole: widget.userRole,
        dayStarted: _dayStarted,
        dayStartTime: _dayStartTime,
        visits: _visits,
        orders: _orders,
        pendingCount: _pendingQueue.length,
        syncing: _syncing,
        onToggleDay: _toggleAttendance,
        onSyncNow: _syncPendingQueue,
        onNewActivity: () => setState(() => _tabIndex = 1),
        onNewOrder: () => setState(() => _tabIndex = 2),
      ),
      NewActivityFlowTab(
        onSaveVisit: _recordVisit,
        onCaptureGps: _captureGps,
        onUploadPhoto: _uploadPhotoToDrive,
      ),
      OrderBookingTab(
        orders: _orders,
        onSaveOrder: _recordOrder,
      ),
      ProfileTab(
        userName: widget.userName,
        userEmail: widget.userEmail,
        userRole: widget.userRole,
        webAppUrl: widget.webAppUrl,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F172A),
        foregroundColor: Colors.white,
        title: const Text(
          'Field Force Connect',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        actions: [
          if (_pendingQueue.isNotEmpty)
            IconButton(
              onPressed: _syncPendingQueue,
              icon: Badge(
                label: Text('${_pendingQueue.length}'),
                child: const Icon(Icons.cloud_upload_outlined),
              ),
              tooltip: 'Sync Pending Records',
            ),
        ],
      ),
      body: pages[_tabIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (idx) => setState(() => _tabIndex = idx),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.play_circle_outline),
            selectedIcon: Icon(Icons.play_circle),
            label: 'Start Visit',
          ),
          NavigationDestination(
            icon: Icon(Icons.shopping_bag_outlined),
            selectedIcon: Icon(Icons.shopping_bag),
            label: 'Orders',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class DashboardTab extends StatelessWidget {
  final String userName;
  final String userRole;
  final bool dayStarted;
  final String? dayStartTime;
  final List<Map<String, dynamic>> visits;
  final List<Map<String, dynamic>> orders;
  final int pendingCount;
  final bool syncing;
  final VoidCallback onToggleDay;
  final VoidCallback onSyncNow;
  final VoidCallback onNewActivity;
  final VoidCallback onNewOrder;

  const DashboardTab({
    super.key,
    required this.userName,
    required this.userRole,
    required this.dayStarted,
    required this.dayStartTime,
    required this.visits,
    required this.orders,
    required this.pendingCount,
    required this.syncing,
    required this.onToggleDay,
    required this.onSyncNow,
    required this.onNewActivity,
    required this.onNewOrder,
  });

  @override
  Widget build(BuildContext context) {
    final todayStr = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final todayVisits =
        visits.where((v) => (v['date'] ?? '').toString().startsWith(todayStr)).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome, $userName',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                userRole,
                style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: onToggleDay,
                      style: FilledButton.styleFrom(
                        backgroundColor: dayStarted
                            ? const Color(0xFFEF4444)
                            : const Color(0xFF10B981),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: Icon(dayStarted ? Icons.stop_circle : Icons.play_arrow),
                      label: Text(
                        dayStarted ? 'End Field Day' : 'Start Field Day (GPS)',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _StatCard(
                label: 'Today Visits',
                value: '$todayVisits',
                color: const Color(0xFF059669),
                icon: Icons.where_to_vote,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatCard(
                label: 'Total Visits',
                value: '${visits.length}',
                color: const Color(0xFF2563EB),
                icon: Icons.fact_check,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatCard(
                label: 'Orders',
                value: '${orders.length}',
                color: const Color(0xFF7C3AED),
                icon: Icons.shopping_cart_checkout,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: onNewActivity,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF059669),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                icon: const Icon(Icons.add_location_alt),
                label: const Text('New Activity / Visit'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onNewOrder,
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                icon: const Icon(Icons.receipt_long),
                label: const Text('Book Order'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const Text(
          'Recent Visits (Multi-Sheet Synced)',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        if (visits.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(
              child: Text(
                'No visits recorded yet. Tap "New Activity / Visit" to start.',
                style: TextStyle(color: Color(0xFF64748B)),
              ),
            ),
          )
        else
          ...visits.take(10).map(
                (v) => Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: const Color(0xFFECFDF5),
                      child: const Icon(Icons.check_circle,
                          color: Color(0xFF059669)),
                    ),
                    title: Text(
                      '${v['activityType']} • ${v['customerName']}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Sheet: ${v['sheetName']} | ${v['date']}\n${(v['photoUrls'] ?? '').toString().isNotEmpty ? "📸 Drive Photo Attached" : "No photo"}',
                    ),
                    isThreeLine: true,
                  ),
                ),
              ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;

  const _StatCard({
    required this.label,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
          ),
        ],
      ),
    );
  }
}

/// Enforces explicit 2-step flow:
/// Step 1: Select Activity Type -> Tap explicit "Start Activity" button
/// Step 2: Fill Visit Details, Capture Photo (uploaded to Google Drive), and Tap "Finish & Complete Activity"
class NewActivityFlowTab extends StatefulWidget {
  final Future<void> Function(Map<String, dynamic> visitData) onSaveVisit;
  final Future<Position?> Function() onCaptureGps;
  final Future<String?> Function(File file, String visitId) onUploadPhoto;

  const NewActivityFlowTab({
    super.key,
    required this.onSaveVisit,
    required this.onCaptureGps,
    required this.onUploadPhoto,
  });

  @override
  State<NewActivityFlowTab> createState() => _NewActivityFlowTabState();
}

class _NewActivityFlowTabState extends State<NewActivityFlowTab> {
  static const List<String> kActivityTypes = [
    'Distributor Visit',
    'Retailer Visit',
    'Farmer Visit',
    'Product Demonstration',
    'Farmer Meeting',
    'Field Day',
  ];

  String _selectedActivity = kActivityTypes.first;
  bool _activityStarted = false;
  DateTime? _startTime;
  Position? _startPosition;
  bool _startingGps = false;
  bool _submitting = false;

  final _customerCtrl = TextEditingController();
  final _contactCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  final _cropCtrl = TextEditingController();
  final _productsCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  final List<File> _capturedPhotos = [];

  Future<void> _handleStartActivity() async {
    setState(() => _startingGps = true);
    final pos = await widget.onCaptureGps();
    setState(() {
      _startingGps = false;
      _activityStarted = true;
      _startTime = DateTime.now();
      _startPosition = pos;
    });
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 75,
      maxWidth: 1280,
    );
    if (picked != null) {
      setState(() {
        _capturedPhotos.add(File(picked.path));
      });
    }
  }

  Future<void> _finishAndSaveActivity() async {
    if (_customerCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter Customer / Party Name')),
      );
      return;
    }
    setState(() => _submitting = true);

    final visitId = 'VIS-${DateTime.now().millisecondsSinceEpoch}';
    final uploadedDriveLinks = <String>[];

    for (final photo in _capturedPhotos) {
      final link = await widget.onUploadPhoto(photo, visitId);
      if (link != null && link.isNotEmpty) {
        uploadedDriveLinks.add(link);
      }
    }

    final endTime = DateTime.now();
    final durationMins = _startTime != null
        ? endTime.difference(_startTime!).inMinutes.clamp(1, 999)
        : 5;

    final visitRecord = {
      'id': visitId,
      'date': DateFormat('yyyy-MM-dd HH:mm').format(endTime),
      'activityType': _selectedActivity,
      'customerName': _customerCtrl.text.trim(),
      'contactPerson': _contactCtrl.text.trim(),
      'mobile': _mobileCtrl.text.trim(),
      'locationName': _locationCtrl.text.trim(),
      'cropFocus': _cropCtrl.text.trim(),
      'productsDiscussed': _productsCtrl.text.trim(),
      'notes': _notesCtrl.text.trim(),
      'startTime': _startTime != null
          ? DateFormat('HH:mm:ss').format(_startTime!)
          : '',
      'endTime': DateFormat('HH:mm:ss').format(endTime),
      'durationMinutes': durationMins,
      'latitude': _startPosition?.latitude?.toString() ?? '',
      'longitude': _startPosition?.longitude?.toString() ?? '',
      'photoUrls': uploadedDriveLinks.join(', '),
    };

    await widget.onSaveVisit(visitRecord);

    setState(() {
      _submitting = false;
      _activityStarted = false;
      _startTime = null;
      _customerCtrl.clear();
      _contactCtrl.clear();
      _mobileCtrl.clear();
      _locationCtrl.clear();
      _cropCtrl.clear();
      _productsCtrl.clear();
      _notesCtrl.clear();
      _capturedPhotos.clear();
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFF059669),
          content: Text(
            'Saved to Google Sheet tab "${resolveSheetNameForActivity(_selectedActivity)}"!',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final targetSheet = resolveSheetNameForActivity(_selectedActivity);

    if (!_activityStarted) {
      return ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Step 1: Select Field Activity Type',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  'Target Google Sheet Tab: $targetSheet',
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFF059669),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                ...kActivityTypes.map(
                  (type) => RadioListTile<String>(
                    value: type,
                    groupValue: _selectedActivity,
                    title: Text(
                      type,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      'Saves to sheet: ${resolveSheetNameForActivity(type)}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    onChanged: (v) {
                      if (v != null) setState(() => _selectedActivity = v);
                    },
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: _startingGps ? null : _handleStartActivity,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF059669),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  icon: _startingGps
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.play_circle_fill),
                  label: Text(
                    _startingGps
                        ? 'Locking GPS Coordinates...'
                        : 'Start $_selectedActivity Now',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFECFDF5),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF10B981)),
          ),
          child: Row(
            children: [
              const Icon(Icons.timer, color: Color(0xFF059669)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Active: $_selectedActivity (Sheet: $targetSheet)',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF065F46),
                  ),
                ),
              ),
              TextButton(
                onPressed: () => setState(() => _activityStarted = false),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _customerCtrl,
          decoration: const InputDecoration(
            labelText: 'Distributor / Retailer / Farmer Name *',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _contactCtrl,
          decoration: const InputDecoration(
            labelText: 'Contact Person',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _mobileCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
            labelText: 'Mobile Number',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _locationCtrl,
          decoration: const InputDecoration(
            labelText: 'Village / Town / Market',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _cropCtrl,
          decoration: const InputDecoration(
            labelText: 'Crop Focus',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _productsCtrl,
          decoration: const InputDecoration(
            labelText: 'Products Discussed / Demonstrated',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _notesCtrl,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Visit Remarks & Outcome',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: _takePhoto,
          icon: const Icon(Icons.camera_alt),
          label: Text(
            'Capture Field Photo (${_capturedPhotos.length} attached -> Google Drive)',
          ),
        ),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: _submitting ? null : _finishAndSaveActivity,
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF059669),
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          icon: _submitting
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white),
                )
              : const Icon(Icons.check_circle),
          label: Text(
            _submitting
                ? 'Uploading Drive Photos & Saving...'
                : 'Complete & Finish Activity',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}

class OrderBookingTab extends StatefulWidget {
  final List<Map<String, dynamic>> orders;
  final Future<void> Function(Map<String, dynamic> orderData) onSaveOrder;

  const OrderBookingTab({
    super.key,
    required this.orders,
    required this.onSaveOrder,
  });

  @override
  State<OrderBookingTab> createState() => _OrderBookingTabState();
}

class _OrderBookingTabState extends State<OrderBookingTab> {
  final _customerCtrl = TextEditingController();
  final _productCtrl = TextEditingController();
  final _qtyCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _transporterCtrl = TextEditingController();
  final _trackingCtrl = TextEditingController();
  String _customerType = 'Distributor';
  String _paymentTerms = 'Credit 30 Days';
  bool _saving = false;

  Future<void> _submitOrder() async {
    final customer = _customerCtrl.text.trim();
    final product = _productCtrl.text.trim();
    final qty = double.tryParse(_qtyCtrl.text.trim()) ?? 0;
    final price = double.tryParse(_priceCtrl.text.trim()) ?? 0;

    if (customer.isEmpty || product.isEmpty || qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Please enter Customer, Product and valid Quantity')),
      );
      return;
    }

    setState(() => _saving = true);
    final totalValue = qty * price;
    await widget.onSaveOrder({
      'id': 'ORD-${DateTime.now().millisecondsSinceEpoch}',
      'date': DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now()),
      'customerName': customer,
      'customerType': _customerType,
      'productName': product,
      'quantity': qty,
      'unitPrice': price,
      'orderValue': totalValue,
      'paymentTerms': _paymentTerms,
      'transporterName': _transporterCtrl.text.trim(),
      'trackingNumber': _trackingCtrl.text.trim(),
      'dispatchDate': _trackingCtrl.text.trim().isNotEmpty
          ? DateFormat('yyyy-MM-dd').format(DateTime.now())
          : '',
      'status':
          _trackingCtrl.text.trim().isNotEmpty ? 'Dispatched' : 'Booked',
    });

    setState(() {
      _saving = false;
      _customerCtrl.clear();
      _productCtrl.clear();
      _qtyCtrl.clear();
      _priceCtrl.clear();
      _transporterCtrl.clear();
      _trackingCtrl.clear();
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Color(0xFF059669),
          content: Text('Order synced to Google Sheet "Orders" tab!'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Book New Order & Dispatch Details',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _customerCtrl,
          decoration: const InputDecoration(
            labelText: 'Distributor / Retailer Name *',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _productCtrl,
          decoration: const InputDecoration(
            labelText: 'Product Name & Pack Size *',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _qtyCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Quantity *',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextField(
                controller: _priceCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Unit Price (₹) *',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _transporterCtrl,
          decoration: const InputDecoration(
            labelText: 'Transporter Name (Optional Dispatch Info)',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _trackingCtrl,
          decoration: const InputDecoration(
            labelText: 'LR / Tracking Number (Optional)',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _saving ? null : _submitOrder,
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF059669),
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          icon: const Icon(Icons.shopping_bag),
          label: Text(_saving ? 'Saving Order...' : 'Submit Order to Sheet'),
        ),
      ],
    );
  }
}

class ProfileTab extends StatelessWidget {
  final String userName;
  final String userEmail;
  final String userRole;
  final String webAppUrl;
  final VoidCallback onLogout;

  const ProfileTab({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.userRole,
    required this.webAppUrl,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Card(
          child: ListTile(
            leading: const CircleAvatar(
              backgroundColor: Color(0xFF059669),
              child: Icon(Icons.person, color: Colors.white),
            ),
            title: Text(userName,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('$userRole\n$userEmail'),
            isThreeLine: true,
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: ListTile(
            leading: const Icon(Icons.table_chart, color: Color(0xFF059669)),
            title: const Text('Connected Google Sheet ID'),
            subtitle: const Text(kSpreadsheetId),
            trailing: IconButton(
              icon: const Icon(Icons.open_in_new),
              onPressed: () {
                launchUrl(Uri.parse(
                    'https://docs.google.com/spreadsheets/d/$kSpreadsheetId/edit'));
              },
            ),
          ),
        ),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          onPressed: onLogout,
          icon: const Icon(Icons.logout, color: Colors.red),
          label: const Text('Sign Out', style: TextStyle(color: Colors.red)),
        ),
      ],
    );
  }
}

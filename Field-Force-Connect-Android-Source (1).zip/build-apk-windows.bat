@echo off
echo ===================================================
echo Building Field Force Connect Native Android APK...
echo ===================================================
cd mobile_app
call flutter create . --project-name field_force_connect --org com.fieldforce --platforms android
call flutter pub get
call flutter build apk --release
copy /Y build\app\outputs\flutter-apk\app-release.apk ..\Field-Force-Connect.apk
cd ..
echo.
echo SUCCESS! Your signed APK is ready at: Field-Force-Connect.apk
pause

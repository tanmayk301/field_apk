#!/usr/bin/env bash
set -e
echo "==================================================="
echo "Building Field Force Connect Native Android APK..."
echo "==================================================="
cd mobile_app
flutter create . --project-name field_force_connect --org com.fieldforce --platforms android
flutter pub get
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk ../Field-Force-Connect.apk
cd ..
echo "SUCCESS! Your signed APK is ready at: ./Field-Force-Connect.apk"
